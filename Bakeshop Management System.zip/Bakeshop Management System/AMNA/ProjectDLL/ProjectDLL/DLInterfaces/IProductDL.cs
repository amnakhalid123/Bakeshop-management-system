﻿using ProjectDLL.BL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectDLL.DLInterfaces
{
    public interface IProductDL
    {
        List<string> GetProductNames();
        bool UpdatePrice(Product product);
        bool AddProduct(Product product);
        bool DeleteWholeProduct(Product product);
        List<Product> GetAllProducts();


    }
}
