﻿using ProjectDLL.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectDLL.DLInterfaces
{
    public interface IMUserDL
    {
        bool SignUP(MUser mUser);
        string SignIn(MUser mUser);
        bool ChangePassword(MUser mUser);


    }
}
