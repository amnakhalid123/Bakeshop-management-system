﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectDLL.BL
{
    public class Admin : MUser
    {
     
        public Admin() { }

        public Admin(string name,string password):base(name, password) { }

        public Admin(string name,string password,string role): base(name, password,role) { }


    }
}
