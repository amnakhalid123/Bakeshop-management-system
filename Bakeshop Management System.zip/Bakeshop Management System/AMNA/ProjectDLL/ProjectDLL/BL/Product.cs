﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectDLL.BL
{
    public class Product
    {
        private string Name;
        private string Category;
        private int Quantity;
        private double Price;

       

        public Product(string name, string category, int quantity, double price)
        {
            Name = name;
            Category = category;
            Quantity = quantity;
            Price = price;
        }
        public Product() { }

        public Product(string name, int quantity)
        {
            Name = name;
            Quantity = quantity;
        }
        public Product(string name)
        {
            Name = name;
        }
        public Product(string name, double price)
        {
            Name = name;
            Price = price;
        }
        public Product(Product p)
        {
            Name = p.Name;
            Category = p.Category;
            Quantity = p.Quantity;
            Price = p.Price;
        }

        public void SetName(string name)
        {
            Name = name;
        }

        public void SetCategory(string category)
        {
            Category = category;
        }

        public string GetCategory()
        {
            return Category;
        }

        public int GetQuantity()
        {
            return Quantity;
        }

        public void SetQuantity(int quantity)
        {
            Quantity = quantity;
        }

        public void SetPrice(double price)
        {
            Price = price;
        }

        public double GetPrice()
        {
            return Price;
        }

        public string GetName()
        {
            return Name;
        }
    }
}
