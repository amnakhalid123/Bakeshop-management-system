﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectDLL.BL
{
    public class Customer : MUser
    {
        private string Name;
        private int Age;
        private string Contact;

        public Customer() { }

        public Customer(string name, int age, string contact)
        {
            Name = name;
            Age = age;
            Contact = contact;
        }

        public Customer(string username,string password,string role):base(username, password, role) { }

        public Customer(string username,string password):base(username, password) { }

        public void SetName(string name)
        {
            Name = name;
        }

        public void SetAge(int age)
        {
            Age = age;
        }

        public string GetName()
        {
            return Name;
        }
        
        public int GetAge()
        {
            return Age;
        }

        public void SetContact(string contact)
        {
            Contact = contact;
        }

        public string GetContact()
        {
            return Contact;
        }
    }
}
