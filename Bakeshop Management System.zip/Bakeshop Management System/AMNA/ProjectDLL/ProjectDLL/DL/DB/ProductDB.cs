﻿using ProjectDLL.BL;
using ProjectDLL.DLInterfaces;
using ProjectDLL.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ProjectDLL.DL.DB
{
    public class ProductDB:IProductDL
    {
        private static string connection = Database.GetConnectionString();

        public List<string> GetProductNames()
        {
            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();
            SqlCommand cmd = new SqlCommand("select Name from Products", sqlConnection);

            SqlDataReader reader = cmd.ExecuteReader();

            List<string> names = new List<string>();

            while (reader.Read())
            {
                names.Add(reader.GetString(0));
            }
            reader
                .Close();
            sqlConnection.Close();
            return names;
        }

        public static bool AddProductQuantity(string name, int newQuantity)
        {

            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();

            SqlCommand sql = new SqlCommand($"select Quantity from Products where Name='{name}'", sqlConnection);
            int OldQuantity = int.Parse(Convert.ToString(sql.ExecuteScalar()));

            SqlCommand sqlCommand = new SqlCommand($"update Products set Quantity=@add where Name='{name}'", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@add", OldQuantity + newQuantity);
            int i = sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            return i > 0;

        }

        public bool UpdatePrice(Product product)
        {

            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand("update Products set Price=@newprice where Name=@name", sqlConnection);
            sql.Parameters.AddWithValue("@newprice", product.GetPrice());
            sql.Parameters.AddWithValue("@name", product.GetName());
            int i = sql.ExecuteNonQuery();
            sqlConnection.Close();
            return i > 0;
        }
        public bool AddProduct(Product product)
        {
            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand("INSERT INTO Products (Name, Category, Quantity, Price) VALUES (@name, @category, @quantity, @price)", sqlConnection);
            sql.Parameters.AddWithValue("@name", product.GetName());
            sql.Parameters.AddWithValue("@category", product.GetCategory());
            sql.Parameters.AddWithValue("@quantity", product.GetQuantity());
            sql.Parameters.AddWithValue("@price", product.GetPrice());
            int i = sql.ExecuteNonQuery();
            sqlConnection.Close();
            return i > 0;
        }
        public static bool AddToCart(Product product)
        {
            using (SqlConnection sqlConnection = new SqlConnection(connection))
            {
                sqlConnection.Open();

                string checkQuery = "SELECT COUNT(*) FROM Products WHERE Name = @Name";
                SqlCommand checkCommand = new SqlCommand(checkQuery, sqlConnection);
                checkCommand.Parameters.AddWithValue("@Name", product.GetName());
                int productExists = (int)checkCommand.ExecuteScalar();

                if (productExists > 0)
                {
                    string getPriceQuery = "SELECT Price FROM Products WHERE Name = @Name";
                    SqlCommand getPriceCommand = new SqlCommand(getPriceQuery, sqlConnection);
                    getPriceCommand.Parameters.AddWithValue("@Name", product.GetName());
                    object priceObj = getPriceCommand.ExecuteScalar();

                    // Check if priceObj is null or cannot be converted to decimal
                    if (priceObj != null && decimal.TryParse(priceObj.ToString(), out decimal price))
                    {
                        // Calculate the total price without causing an overflow
                        decimal totalPrice;
                        try
                        {
                            totalPrice = decimal.Multiply(price, product.GetQuantity());
                        }
                        catch (OverflowException)
                        {
                            // Handle overflow condition by setting total price to maximum value
                            totalPrice = decimal.MaxValue;
                        }

                        string insertQuery = "INSERT INTO Cart (Name, Quantity, Price) VALUES (@Name, @Quantity, @TotalPrice)";
                        SqlCommand insertCommand = new SqlCommand(insertQuery, sqlConnection);
                        insertCommand.Parameters.AddWithValue("@Name", product.GetName());
                        insertCommand.Parameters.AddWithValue("@Quantity", product.GetQuantity());
                        insertCommand.Parameters.AddWithValue("@TotalPrice", totalPrice);

                        int rowsAffected = insertCommand.ExecuteNonQuery();

                        string updateQuantityQuery = "UPDATE Products SET Quantity = Quantity - @Quantity WHERE Name = @Name";
                        SqlCommand updateQuantityCommand = new SqlCommand(updateQuantityQuery, sqlConnection);
                        updateQuantityCommand.Parameters.AddWithValue("@Quantity", product.GetQuantity());
                        updateQuantityCommand.Parameters.AddWithValue("@Name", product.GetName());
                        updateQuantityCommand.ExecuteNonQuery();

                        return rowsAffected > 0;
                    }
                    else
                    {
                        // Handle the case where the price is null or cannot be converted to decimal
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
        }

        public bool DeleteWholeProduct(Product product)
        {
            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand("DELETE FROM Products WHERE Name = @name", sqlConnection);
            sql.Parameters.AddWithValue("@name", product.GetName());
            int i = sql.ExecuteNonQuery();
            sqlConnection.Close();
            return i > 0;
        }
        public static DataTable GetCart()
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    string query = "SELECT * FROM Cart";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, sqlConnection);
                    DataTable cartTable = new DataTable();
                    adapter.Fill(cartTable);

                    return cartTable;
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine($"An error occurred: {ex.Message}");
                return null;
            }
        }

        public static bool DeleteProduct(Product product)
        {

            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();

            SqlCommand sql = new SqlCommand($"select Quantity from Products where Name='{product.GetName()}'", sqlConnection);
            int OldQuantity = int.Parse(Convert.ToString(sql.ExecuteScalar()));

            SqlCommand sqlCommand = new SqlCommand($"update Products set Quantity=@add where Name='{product.GetName()}'", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@add", OldQuantity - product.GetQuantity());
            int i = sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            return i > 0;
        }

        public static DataTable ViewProducts()
        {
            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand("select Name,Category,Quantity,Price from Products", sqlConnection);
            SqlDataAdapter adapter = new SqlDataAdapter(sql);
            DataTable Products = new DataTable();
            adapter.Fill(Products);
            sqlConnection.Close();
            return Products;
        }
        public static decimal CheckoutCart()
        {
            decimal totalPrice = 0;

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    string selectQuery = "SELECT Price FROM Cart";
                    SqlCommand selectCommand = new SqlCommand(selectQuery, sqlConnection);
                    SqlDataReader reader = selectCommand.ExecuteReader();
                    while (reader.Read())
                    {
                        totalPrice += Convert.ToDecimal(reader["Price"]);
                    }
                    reader.Close();
                    string deleteQuery = "DELETE FROM Cart";
                    SqlCommand deleteCommand = new SqlCommand(deleteQuery, sqlConnection);
                    deleteCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
          
                Console.WriteLine($"An error occurred: {ex.Message}");
                throw; 
            }

            return totalPrice;
        }

        public List<Product> GetAllProducts()
        {
            throw new NotImplementedException();
        }
    }
}
