﻿using ProjectDLL.BL;
using ProjectDLL.DLInterfaces;
using ProjectDLL.Utility;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectDLL.DL.DB
{
    public class MUserDB : IMUserDL
    {
        private static string connection = Database.GetConnectionString();

        public  bool SignUP(MUser mUser)
        {
            if (SignIn(mUser) == null && !UsernameCheck(mUser.GetUserName()))
            {
                SqlConnection sqlConnection = new SqlConnection(connection);
                sqlConnection.Open();
                SqlCommand cmd = new SqlCommand("insert into MUser values (@username,@password,@role)", sqlConnection);
                cmd.Parameters.AddWithValue("@username", mUser.GetUserName());
                cmd.Parameters.AddWithValue("@password", mUser.GetPassword());
                cmd.Parameters.AddWithValue("@role", mUser.GetUserRole());
                int row = cmd.ExecuteNonQuery();
                sqlConnection.Close();
                
                return row > 0;
            }
            else
            {
                return false;
            }
        }

        public string SignIn(MUser mUser)
        {
            foreach (string name in GetUsernames())
            {
                if (name == mUser.GetUserName())
                {
                    SqlConnection sqlConnection = new SqlConnection(connection);
                    sqlConnection.Open();

                    SqlCommand sqlCommand = new SqlCommand("SELECT UserRole from MUser where UserName=@user AND Password=@password", sqlConnection);
                    sqlCommand.Parameters.AddWithValue("@user", mUser.GetUserName());
                    sqlCommand.Parameters.AddWithValue("@password", mUser.GetPassword());
                    string role = Convert.ToString(sqlCommand.ExecuteScalar());
                    sqlConnection.Close();

                    if (role != "")
                    {
                        return role;
                    }
                }
            }
            return null;
        }

        private List<string> GetUsernames()
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();

            SqlCommand command = new SqlCommand("SELECT UserName FROM MUser", con);
            SqlDataReader datareader = command.ExecuteReader();
            List<string> username = new List<string>();

            while (datareader.Read())
            {
                username.Add(datareader.GetString(0));
            }
            datareader.Close();
            con.Close();
            return username;
        }
        private bool UsernameCheck(string userName)
        {
            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) from MUser where UserName=@user", sqlConnection);
            cmd.Parameters.AddWithValue("@user", userName);
            int check = (int)cmd.ExecuteScalar();
            sqlConnection.Close();

            return check > 0;
        }
        public bool ChangePassword(MUser mUser)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();

                    // Update the password in the database
                    string query = "UPDATE MUser SET Password = @NewPassword WHERE Username = @Username";
                    using (SqlCommand command = new SqlCommand(query, sqlConnection))
                    {
                        command.Parameters.AddWithValue("@NewPassword", mUser.GetPassword());
                        command.Parameters.AddWithValue("@Username", mUser.GetUserName());
                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0; // Return true if password was updated successfully
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception or handle it appropriately
                Console.WriteLine($"An error occurred: {ex.Message}");
                return false; // Return false to indicate that an error occurred
            }
        }
    }
}
