﻿using ProjectDLL.BL;
using ProjectDLL.DLInterfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ProjectDLL.DL.FH
{
    public class ProductFH:IProductDL
    {
        private static List<Product> products = new List<Product>();

        public ProductFH()
        {
            if (ReadFromFile())
            {
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Error");
            }
        }

        public List<Product> GetAllProducts()
        {
            return products;
        }
        public bool AddProduct(Product product)
        {
            products.Add(product);

            StreamWriter streamWriter = new StreamWriter("Products.txt", true);
            streamWriter.WriteLine($"{product.GetName()},{product.GetCategory()},{product.GetQuantity()},{product.GetPrice()}");
            streamWriter.Flush();
            streamWriter.Close();
            WriteToFile();
            return true;
        }

        public bool DeleteWholeProduct(Product product)
        {
            foreach(Product p in products)
            {
                if (p.GetName() == product.GetName())
                {
                    products.Remove(p);
                    WriteToFile();

                    return true;
                }
            }
            return false;
        }

        public List<string> GetProductNames()
        {
            List<string> names = new List<string>();
            foreach (Product product in products)
            {
                names.Add(product.GetName());
            }
            return names;
        }

        public bool UpdatePrice(Product product)
        {
            foreach(Product p in products)
            {
                if (p.GetName() == product.GetName())
                {
                    p.SetPrice(product.GetPrice());

                    WriteToFile();
                }
            }
            return true;
        }

        private bool ReadFromFile()
        {

            StreamReader streamReader = new StreamReader("Products.txt");
            string record;

            if (File.Exists("Products.txt"))
            {
                while ((record = streamReader.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string Name = splittedRecord[0];
                    string Category = splittedRecord[1];
                    int Quantity = int.Parse(splittedRecord[2]);
                    double Price = double.Parse(splittedRecord[3]);

                    Product product = new Product(Name,Category,Quantity,Price);
                    products.Add(product);
                }
                streamReader.Close();
                return true;
            }
            else
            {
                return false;
            }
        }

        private void WriteToFile()
        {

            StreamWriter streamWriter = new StreamWriter("Products.txt");

            foreach (Product product in products)
            {
                streamWriter.WriteLine($"{product.GetName()},{product.GetCategory()},{product.GetQuantity()},{product.GetPrice()}");
            }

            streamWriter.Close();
        }
    }
}
