﻿using ProjectDLL.BL;
using ProjectDLL.DL.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleProject.UI
{
    internal class ProductUI
    {

        public static string MainMenu()
        {
            Console.WriteLine("\n1. View Products");
            Console.WriteLine("2. Add New Product");
            Console.WriteLine("3. Delete Product");
            Console.WriteLine("4. Update Product Price");
            Console.WriteLine("5. Exit\n");

            Console.Write("Your option is .... ");
            string option = Console.ReadLine();

            return option;
        }

        public static string ViewProducts()
        {
            
            List<Product> products = ObjectHandler.GetProductDL().GetAllProducts();

            if (products.Count != 0)
            {
                foreach (Product product in products)
                {
                    Console.WriteLine($"Name: {product.GetName()} \t Category: {product.GetCategory()} \t Quantity: {product.GetQuantity()} \t Price: {product.GetPrice()}\n");
                }
                return "Current Products";
            }
            else
            {
                return "No Current Products";
            }
        }

        public static string AddProduct()
        {
            while (true)
            {
                try
                {
                    Console.Write("Enter Name Of Product: ");
                    string name = Console.ReadLine();

                    Console.Write("Enter Category: ");
                    string category = Console.ReadLine();

                    Console.Write("Enter Total Quantity Of The Product: ");
                    int quantity = int.Parse(Console.ReadLine());

                    Console.Write("Enter Price Of The Product: ");
                    double price = double.Parse(Console.ReadLine());

                    Console.WriteLine();

                    Product product = new Product(name,category,quantity,price);

                    if (ObjectHandler.GetProductDL().AddProduct(product))
                    {
                        return "Product Added Successfully!";
                    }
                    else
                    {
                        return "Error 404!";
                    }
                }
                catch
                {
                    Console.WriteLine("\nEnter Valid Input!");
                    Console.WriteLine("\nPress Any Key to Continue..");
                    Console.ReadKey();
                    Console.Clear();

                }
            }
        }

        public static string DeleteProduct()
        {
            while (true)
            {
                List<string> Products = ObjectHandler.GetProductDL().GetProductNames();
               
                foreach (string Product in Products)
                {
                    Console.WriteLine($"{Product}");
                    
                }

                Console.Write("\nEnter Name Of Product You Want To Delete: ");
                string name = Console.ReadLine();

                Product product = new Product(name);


                if (ObjectHandler.GetProductDL().DeleteWholeProduct(product))
                {
                    return "Product Removed!";
                }
                else
                {
                    Console.WriteLine("Enter Correct Product Name!");
                    Console.WriteLine("\nPress Any Key to Continue..");
                    Console.ReadKey();
                    Console.Clear();
                }

            }
        }


        public static string UpdatePrice()
        {
            while (true)
            {
                try
                {
                    List<string> Products = ObjectHandler.GetProductDL().GetProductNames();

                    foreach (string Product in Products)
                    {
                        Console.WriteLine($"{Product}");

                    }

                    Console.Write("\nEnter Name Of Product You Want To Update Price Of: ");
                    string name = Console.ReadLine();

                    Console.Write("Enter New Price: ");
                    double price  = double.Parse(Console.ReadLine());

                    Product product = new Product(name, price);

                    if (ObjectHandler.GetProductDL().UpdatePrice(product))
                    {
                        return "Product Price Updated!";
                    }
                    else
                    {
                        return "Error!";
                    }
                }
                catch
                {
                    Console.WriteLine("\nEnter Valid Input!");
                    Console.WriteLine("\nPress Any Key to Continue..");
                    Console.ReadKey();
                    Console.Clear();
                }
            }
        }
    }
}
