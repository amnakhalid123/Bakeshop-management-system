﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjectDLL.BL;

namespace WindowsformProject
{
    public partial class AdminOp7 : Form
    {
        public AdminOp7()
        {
            InitializeComponent();
            FillCOmboBox();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void FillCOmboBox()
        {
            comboBox1.Items.Clear();

            foreach (string s in ObjectHandler.GetProductDL().GetProductNames())
            {
                comboBox1.Items.Add(s);
            }

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

          
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminMenu adminMenu = new AdminMenu();
            adminMenu.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                try
                {
                    string name = comboBox1.Text;

                    Product product = new Product(name);
                    if (ObjectHandler.GetProductDL().DeleteWholeProduct(product))
                    {
                        MessageBox.Show("Product Deleted Successfully!");
                        comboBox1.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Error!");
                    }
                }
                catch
                {
                    MessageBox.Show("Enter Integer In Quantity");
                }
            }
            else
            {
                MessageBox.Show("Input All Data.");
            }
        }
    }
}
