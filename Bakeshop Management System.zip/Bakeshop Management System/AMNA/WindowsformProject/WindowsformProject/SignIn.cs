﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjectDLL.BL;


namespace WindowsformProject
{
    public partial class SignIn : Form
    {
        public SignIn()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        
            {
                
            }

            private void button2_Click(object sender, EventArgs e)
            {
               
            }

            private void pictureBox1_Click(object sender, EventArgs e)
            {

            }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Main_Menu main_Menu = new Main_Menu();
            main_Menu.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty || textBox2.Text == string.Empty)
            {
                MessageBox.Show("Input All Data First!");
            }
            else
            {
                string username = textBox1.Text;
                string password = textBox2.Text;
                MUser user = new MUser(username, password);

                if (ObjectHandler.GetUserDL().SignIn(user) != null)
                {

                    user.SetRole(ObjectHandler.GetUserDL().SignIn(user));

                    if (user.GetUserRole() == "Customer")
                    {

                        CustomerMenu customerMenu = new CustomerMenu();
                        customerMenu.Show();
                        this.Hide();
                    }
                    else if (user.GetUserRole() == "Admin")
                    {
                        AdminMenu adminMenu = new AdminMenu();
                        adminMenu.Show();
                        this.Hide();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Credentials!!!");
                }

            }
        }
    }
}
