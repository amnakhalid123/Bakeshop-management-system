﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectDLL.DLInterfaces;
using ProjectDLL.DL.DB;

namespace WindowsformProject
{
    internal class ObjectHandler
    {
        private static IMUserDL userDL = new MUserDB();
        private static IProductDL productDL = new ProductDB();

        public static IMUserDL GetUserDL()
        {
            return userDL;
        }

        public static IProductDL GetProductDL()
        {
            return productDL;
        }
    }
}
