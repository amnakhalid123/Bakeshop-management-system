﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjectDLL.BL;

namespace WindowsformProject
{
    public partial class AdminOp3 : Form
    {
        public AdminOp3()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && comboBox2.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                try
                {
                    string name = textBox1.Text;
                    string category = comboBox2.Text;
                    int quantity = int.Parse(textBox2.Text);
                    double price = double.Parse(textBox3.Text);
                    Product product = new Product(name, category, quantity, price);
                    if (ObjectHandler.GetProductDL().AddProduct(product))
                    {
                        MessageBox.Show("Product Added Successfully!");
                        comboBox2.Text = "";
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Error!");
                    }
                }
                catch
                {
                    MessageBox.Show("Enter Integer In Quantity");
                }
            }
            else
            {
                MessageBox.Show("Input All Data.");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminMenu adminMenu = new AdminMenu();
            adminMenu.Show();

        }
    }
}
