﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjectDLL.BL;

namespace WindowsformProject
{
    public partial class AdminOp1 : Form
    {
        public AdminOp1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            string name = textBox1.Text;
            string password = (textBox2.Text);
            MUser muser = new MUser(name, password);
            if (ObjectHandler.GetUserDL().ChangePassword(muser))
            {
                MessageBox.Show("Password Changed Successfully!");

                textBox1.Text = "";
                textBox2.Text = "";

            }
            else
            {
                MessageBox.Show("Error!");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminMenu adminMenu = new AdminMenu();
            adminMenu.Show();
        }
    }
}
