﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsformProject
{
    public partial class AdminMenu : Form
    {
        public AdminMenu()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void button7_Click(object sender, EventArgs e)
        {
        
        }



        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminOp1 op1 = new AdminOp1();
            op1.Show();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminOp3 adminOp3 = new AdminOp3();
            adminOp3.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminOp5 op5 = new AdminOp5();
            op5.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminOp2 op2 = new AdminOp2();
            op2.Show();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminOp4 op4 = new AdminOp4();
            op4.Show();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminOp6 op6 = new AdminOp6();
            op6.Show();
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminOp7 adminOp7 = new AdminOp7();
            adminOp7.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Main_Menu main_Menu = new Main_Menu();
            main_Menu.Show();
        }
    }
}
