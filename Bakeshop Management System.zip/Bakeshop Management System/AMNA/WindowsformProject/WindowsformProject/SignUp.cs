﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ProjectDLL.BL;

namespace WindowsformProject
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
        private void button2_Click(object sender, EventArgs e)
        {

           
        }
        private bool UsernameValidations(string username)
        {

            int len = username.Length;

            for (int i = 0; i < len; i++)
            {
                if (username[i] == ' ')
                {
                    return false;
                }
            }

            return true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty || textBox2.Text == string.Empty)
            {
                MessageBox.Show("Input All Data First");
            }
            else
            {
                string username = textBox1.Text;
                string password = textBox2.Text;
                string role = "Customer";

                if (UsernameValidations(username))
                {
                    MUser user = new MUser(username, password, role);

                    if (ObjectHandler.GetUserDL().SignUP(user))
                    {
                        MessageBox.Show("Your Account Has Been Created.");
                        textBox1.Text = string.Empty;
                        textBox2.Text = string.Empty;

                    }
                    else
                    {
                        MessageBox.Show("UserName Already In Use!");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Input! There should be no space in Username!");
                }

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Main_Menu main_Menu = new Main_Menu();
            main_Menu.Show();
        }
    }
}
