﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsformProject
{
    public partial class CustomerMenu : Form
    {
        public CustomerMenu()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            CustomerOp1 op1 = new CustomerOp1();
            op1.Show();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            CustomerOp2 op2 = new CustomerOp2();
            op2.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            this.Hide();
            CustomerOp3 op3 = new CustomerOp3();
            op3.Show();
        }


        private void button5_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            CustomerOp4 op4 = new CustomerOp4();
            op4.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            CustomerOp5 op5 = new CustomerOp5();
            op5.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AboutForm aboutForm = new AboutForm();
            aboutForm.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Main_Menu main_Menu = new Main_Menu();
            main_Menu.Show();
        }
    }
}
